package com.study.board;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.study.utility.Utility;

@Controller
public class BoardController {

  @Autowired
  @Qualifier("com.study.board.BoardServiceImpl")
  private BoardService dao;
  
  @GetMapping("/board/list")
  public String list(HttpServletRequest request) {
    
    //검색 관련 --------------------------
    String col = Utility.checkNull(request.getParameter("col"));
    String word = Utility.checkNull(request.getParameter("word"));

    if(col.equals("total")) word = "";

    //페이징 관련 ------------------------
    int nowPage = 1;
    if(request.getParameter("nowPage") != null) {
      nowPage = Integer.parseInt(request.getParameter("nowPage"));
    }

    int recordPerPage = 15;

    int sno = ((nowPage-1) * recordPerPage);
    int eno = recordPerPage;
    
    // 1. model 사용
    Map map = new HashMap();
    map.put("col", col);
    map.put("word", word);
    map.put("sno", sno);
    map.put("eno", eno);
    
    List<BoardDTO> list = dao.list(map);
    int total = dao.total(map);
    String paging = Utility.paging(total, nowPage, recordPerPage, col, word);
    
    // 2. request 저장(view에서 사용할 내용을 저장)
    request.setAttribute("list", list);
    request.setAttribute("paging", paging);
    request.setAttribute("col", col);
    request.setAttribute("word", word);
    request.setAttribute("nowPage", nowPage);
    
    return "/board/list";
  }
  
  @GetMapping("/board/list/{weather}")
  public String list(HttpServletRequest request, @PathVariable("weather") String weather) {
    
    //검색 관련 --------------------------
    String col = Utility.checkNull(request.getParameter("col"));
    String word = Utility.checkNull(request.getParameter("word"));

    if(col.equals("total")) word = "";

    //페이징 관련 ------------------------
    int nowPage = 1;
    if(request.getParameter("nowPage") != null) {
      nowPage = Integer.parseInt(request.getParameter("nowPage"));
    }

    int recordPerPage = 15;

    int sno = ((nowPage-1) * recordPerPage);
    int eno = recordPerPage;
    
    // 1. model 사용
    Map map = new HashMap();
    map.put("col", col);
    map.put("word", word);
    map.put("sno", sno);
    map.put("eno", eno);
    
    List<BoardDTO> list = dao.list_sunny(map);

    
    int total = dao.total(map);
    String paging = Utility.paging(total, nowPage, recordPerPage, col, word);
    
    // 2. request 저장(view에서 사용할 내용을 저장)
    request.setAttribute("list", list);
    request.setAttribute("paging", paging);
    request.setAttribute("col", col);
    request.setAttribute("word", word);
    request.setAttribute("nowPage", nowPage);
    
    if(weather.equals("sunny")) return "/weather/sunny";
    else if(weather.equals("fog")) return "/weather/fog";
    else return "/weather/rain";
  }
}
